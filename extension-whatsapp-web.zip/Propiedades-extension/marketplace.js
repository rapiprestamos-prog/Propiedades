// En Facebook Marketplace: llena el anuncio (fotos, título, precio, descripción, área y ubicación)
// con la lista que mandaste desde el portal. Tú revisas, eliges las opciones y tocas Publicar.
(() => {
  let barra = null, ocupado = false;
  const visible = (el) => !!el && el.offsetParent !== null;
  const enCrear = () => /\/marketplace\/create/.test(location.pathname);
  const leer = () => new Promise((r) => chrome.storage.local.get("colaMk", ({ colaMk }) => r(colaMk || null)));
  const guardar = (c) => new Promise((r) => chrome.storage.local.set({ colaMk: c }, r));

  function etiqueta(el) {
    let t = (el.getAttribute("aria-label") || "") + " " + (el.getAttribute("placeholder") || "");
    const l = el.closest("label"); if (l) t += " " + l.innerText;
    if (el.id) { const x = document.querySelector(`label[for="${CSS.escape(el.id)}"]`); if (x) t += " " + x.innerText; }
    const lb = el.getAttribute("aria-labelledby"); if (lb) lb.split(/\s+/).forEach((id) => { const x = document.getElementById(id); if (x) t += " " + x.innerText; });
    return t.toLowerCase();
  }
  function escribir(el, v) {
    el.focus();
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.blur();
  }
  function foto(url) {
    return new Promise((res, rej) => chrome.runtime.sendMessage({ tipo: "FOTO", url }, (r) => {
      if (!r || !r.ok) return rej(new Error((r && r.error) || "no se pudo bajar una foto"));
      fetch(r.dataUrl).then((x) => x.blob()).then((b) => res(new File([b], url.split("/").pop().split("?")[0] || "foto.jpg", { type: b.type || "image/jpeg" }))).catch(rej);
    }));
  }

  async function llenar() {
    const cola = await leer(); if (!cola || ocupado) return;
    const it = cola.items[cola.i]; if (!it) return;
    ocupado = true; pintar("Llenando el anuncio…");
    const hecho = [], falta = [];
    try {
      // Fotos
      const inp = [...document.querySelectorAll('input[type="file"]')].find((x) => /image/.test(x.accept || "")) || document.querySelector('input[type="file"]');
      if (inp && it.fotos && it.fotos.length) {
        const files = []; for (const u of it.fotos.slice(0, 20)) { try { files.push(await foto(u)); } catch (e) {} }
        if (files.length) {
          const dt = new DataTransfer(); files.forEach((f) => dt.items.add(f));
          inp.files = dt.files; inp.dispatchEvent(new Event("input", { bubbles: true })); inp.dispatchEvent(new Event("change", { bubbles: true }));
          hecho.push(files.length + " fotos");
        } else falta.push("fotos");
      } else falta.push("fotos");
      // Textos
      const campos = [...document.querySelectorAll('input:not([type="file"]):not([type="hidden"]):not([type="checkbox"]):not([type="radio"]), textarea')].filter(visible);
      const usar = (re, valor, nombre) => {
        if (valor == null || valor === "") return;
        const c = campos.find((el) => re.test(etiqueta(el)) && !el.value);
        if (c) { escribir(c, String(valor)); hecho.push(nombre); } else falta.push(nombre);
      };
      usar(/t[íi]tulo/, it.titulo, "título");
      usar(/precio/, String(it.precio || "").replace(/[^\d.]/g, ""), "precio");
      usar(/descripci/, it.desc, "descripción");
      usar(/metros|m²|m2|superficie|tamaño/, it.m2 ? String(Math.round(it.m2)) : "", "área");
      usar(/direcci|ubicaci/, it.ubic, "ubicación");
      pintar(`Listo ${it.c}: ${hecho.join(", ") || "nada"}.${falta.length ? " Llénalo tú: " + falta.join(", ") + "." : ""} Elige el tipo (venta) y las opciones que falten, revisa y publica. Después toca «Siguiente».`);
    } catch (e) { pintar("No se pudo llenar: " + (e.message || e)); }
    ocupado = false;
  }

  function boton(txt, fn, color) {
    const b = document.createElement("button"); b.textContent = txt; b.onclick = fn;
    b.style.cssText = `border:0;border-radius:8px;padding:6px 10px;font:600 13px system-ui;cursor:pointer;background:${color || "#fff"};color:${color ? "#fff" : "#0b1f4d"}`;
    return b;
  }
  async function pintar(msg) {
    const cola = await leer();
    if (!cola || !cola.items || !cola.items.length || !/\/marketplace/.test(location.pathname)) { if (barra) { barra.remove(); barra = null; } return; }
    if (!barra) {
      barra = document.createElement("div");
      barra.style.cssText = "position:fixed;z-index:2147483647;left:50%;bottom:16px;transform:translateX(-50%);max-width:94vw;background:#0b1f4d;color:#fff;padding:10px 12px;border-radius:12px;font:500 13px system-ui,sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.35);display:flex;flex-wrap:wrap;gap:8px;align-items:center";
      document.body.appendChild(barra);
    }
    const it = cola.items[cola.i];
    barra.innerHTML = "";
    const t = document.createElement("span"); t.style.cssText = "flex:1 1 260px";
    t.textContent = msg || (it ? `Propiedades · anuncio ${cola.i + 1} de ${cola.items.length}: ${it.c} · ${it.titulo}` : "Terminaste la lista.");
    barra.appendChild(t);
    if (it && enCrear()) barra.appendChild(boton("Llenar este anuncio", llenar, "#1a7f4b"));
    if (it && !enCrear()) barra.appendChild(boton("Abrir formulario", () => { location.href = cola.ruta || "https://www.facebook.com/marketplace/create"; }, "#1a7f4b"));
    barra.appendChild(boton("◀", async () => { const c = await leer(); c.i = Math.max(0, c.i - 1); await guardar(c); pintar(); }));
    barra.appendChild(boton("Siguiente ▶", async () => { const c = await leer(); c.i = Math.min(c.items.length, c.i + 1); if (enCrear()) c.ruta = location.pathname; await guardar(c); if (c.i < c.items.length) location.href = "https://www.facebook.com" + (c.ruta || "/marketplace/create"); else pintar(); }));
    barra.appendChild(boton("Cerrar lista", () => { chrome.storage.local.remove("colaMk"); if (barra) { barra.remove(); barra = null; } }));
  }

  let ultima = "";
  setInterval(() => { if (location.href !== ultima) { ultima = location.href; if (enCrear()) leer().then((c) => { if (c) { c.ruta = location.pathname; guardar(c); } }); pintar(); } }, 800);
  chrome.storage.onChanged.addListener((c) => { if (c.colaMk) pintar(); });
})();
