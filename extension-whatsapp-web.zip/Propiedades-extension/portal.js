// En el portal: avisa que la extensión está instalada y guarda la imagen y el texto que se van a mandar.
document.documentElement.dataset.propWaExt = "1";
window.addEventListener("message", (e) => {
  if (e.source !== window || !e.data || e.data.tipo !== "PROP_WA_ENVIAR") return;
  const { img, texto } = e.data;
  if (typeof img !== "string" || !img.startsWith("data:image/")) return;
  chrome.storage.local.set({ pendiente: { img, texto: String(texto || "").slice(0, 4000), t: Date.now() } }, () => {
    window.postMessage({ tipo: "PROP_WA_LISTO" }, "*");
  });
});

// Lista de anuncios para Marketplace.
window.addEventListener("message", (e) => {
  if (e.source !== window || !e.data || e.data.tipo !== "PROP_MK_COLA") return;
  const items = Array.isArray(e.data.items) ? e.data.items.slice(0, 50) : [];
  chrome.storage.local.set({ colaMk: { items, i: 0, t: Date.now(), ruta: "" } }, () => window.postMessage({ tipo: "PROP_MK_LISTO", n: items.length }, "*"));
});
