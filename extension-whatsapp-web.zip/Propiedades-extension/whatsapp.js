// En WhatsApp Web: cuando abres un chat, pone la imagen y el texto que mandaste desde el portal.
// Tú solo eliges el chat y tocas Enviar. No envía nada por su cuenta.
(() => {
  const VIGENCIA = 10 * 60 * 1000; // 10 minutos
  let item = null, aviso = null, ocupado = false, chatInicial = null, forzar = false;

  const $ = (s, r = document) => r.querySelector(s);
  const visible = (el) => !!el && el.offsetParent !== null;
  const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

  function mostrarAviso(txt, color) {
    if (!aviso) {
      aviso = document.createElement("div");
      aviso.style.cssText = "position:fixed;z-index:2147483647;left:50%;top:14px;transform:translateX(-50%);max-width:92vw;padding:10px 14px;border-radius:10px;font:600 14px system-ui,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.25);display:flex;gap:10px;align-items:center";
      document.body.appendChild(aviso);
    }
    aviso.style.background = color || "#0b1f4d"; aviso.style.color = "#fff";
    aviso.innerHTML = "";
    const s = document.createElement("span"); s.textContent = txt; aviso.appendChild(s);
    if (item && cajaChat() && !forzar) {
      const p = document.createElement("button"); p.textContent = "Ponerla en este chat";
      p.style.cssText = "border:0;border-radius:8px;padding:4px 10px;font:600 13px system-ui;cursor:pointer;background:#25d366;color:#fff";
      p.onclick = () => { forzar = true; poner(); };
      aviso.appendChild(p);
    }
    if (item) {
      const b = document.createElement("button"); b.textContent = "Cancelar";
      b.style.cssText = "border:0;border-radius:8px;padding:4px 10px;font:600 13px system-ui;cursor:pointer";
      b.onclick = () => { chrome.storage.local.remove("pendiente"); item = null; quitarAviso(); };
      aviso.appendChild(b);
    }
  }
  function quitarAviso() { if (aviso) { aviso.remove(); aviso = null; } }

  // Caja de escribir del chat abierto (abajo).
  function cajaChat() {
    const L = [...document.querySelectorAll('footer div[contenteditable="true"], #main div[contenteditable="true"][role="textbox"]')].filter(visible);
    return L[L.length - 1] || null;
  }
  // Caja del comentario cuando ya está la vista previa de la imagen.
  function cajaComentario(antes) {
    const L = [...document.querySelectorAll('div[contenteditable="true"]')].filter((el) => visible(el) && !antes.includes(el) && !el.closest("footer"));
    return L[L.length - 1] || null;
  }

  function tituloChat() {
    const h = $("#main header"); if (!h) return null;
    const t = h.querySelector('span[dir="auto"], span[title]');
    return t ? (t.getAttribute("title") || t.textContent || "").trim() : "chat";
  }

  async function aArchivo(dataUrl) {
    const r = await fetch(dataUrl); const b = await r.blob();
    const ext = b.type === "image/png" ? "png" : "jpg";
    return new File([b], "propiedad." + ext, { type: b.type });
  }

  async function poner() {
    if (ocupado || !item) return;
    const caja = cajaChat(); if (!caja) return;
    if (!forzar && chatInicial !== null && tituloChat() === chatInicial) return; // espera a que elijas el chat
    ocupado = true;
    try {
      const archivo = await aArchivo(item.img);
      const antes = [...document.querySelectorAll('div[contenteditable="true"]')];
      caja.focus();
      // 1) pegar la imagen como si fuera Ctrl+V
      const dt = new DataTransfer(); dt.items.add(archivo);
      caja.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
      let com = null;
      for (let i = 0; i < 25 && !com; i++) { await esperar(200); com = cajaComentario(antes); }
      // 2) si no funcionó, soltarla como si la arrastraras
      if (!com) {
        const zona = $("#main") || caja;
        const dt2 = new DataTransfer(); dt2.items.add(archivo);
        for (const t of ["dragenter", "dragover", "drop"]) zona.dispatchEvent(new DragEvent(t, { dataTransfer: dt2, bubbles: true, cancelable: true }));
        for (let i = 0; i < 25 && !com; i++) { await esperar(200); com = cajaComentario(antes); }
      }
      if (!com) { mostrarAviso("No se pudo poner la imagen sola. Presiona Ctrl+V en el chat (la imagen está copiada) y envía.", "#9a3412"); ocupado = false; return; }
      // 3) el texto va como comentario de la imagen
      if (item.texto) { com.focus(); document.execCommand("insertText", false, item.texto); }
      chrome.storage.local.remove("pendiente"); item = null; forzar = false;
      mostrarAviso("Listo: revisa y toca Enviar.", "#1a7f4b"); setTimeout(quitarAviso, 6000);
    } catch (e) {
      mostrarAviso("No se pudo poner la imagen: " + (e && e.message ? e.message : e), "#9a3412");
    }
    ocupado = false;
  }

  function revisar() {
    chrome.storage.local.get("pendiente", ({ pendiente }) => {
      if (!pendiente || Date.now() - pendiente.t > VIGENCIA) { if (pendiente) chrome.storage.local.remove("pendiente"); item = null; return; }
      if (!item || item.t !== pendiente.t) { item = pendiente; forzar = false; chatInicial = cajaChat() ? tituloChat() : null; mostrarAviso("Propiedades: abre el chat del cliente y la imagen se pone sola."); }
      poner();
    });
  }
  revisar();
  setInterval(revisar, 1000);
  chrome.storage.onChanged.addListener((c) => { if (c.pendiente) revisar(); });
})();
