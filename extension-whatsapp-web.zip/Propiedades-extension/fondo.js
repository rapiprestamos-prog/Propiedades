// Baja las fotos de la página de propiedades para ponerlas en Marketplace.
const PERMITIDOS = [/^https:\/\/propiedades\.mifibienes\.com\//, /^https:\/\/rapiprestamos-prog\.github\.io\//, /^https:\/\/[a-z0-9]+\.supabase\.co\/storage\/v1\/object\/public\/fotos\//];
chrome.runtime.onMessage.addListener((m, _s, responder) => {
  if (!m || m.tipo !== "FOTO") return;
  if (!PERMITIDOS.some((re) => re.test(m.url))) { responder({ ok: false, error: "dirección no permitida" }); return; }
  fetch(m.url).then((r) => { if (!r.ok) throw new Error("HTTP " + r.status); return r.blob(); })
    .then((b) => new Promise((res) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.readAsDataURL(b); }))
    .then((dataUrl) => responder({ ok: true, dataUrl }))
    .catch((e) => responder({ ok: false, error: String(e.message || e) }));
  return true;
});
